package com.knf.dev.librarymanagementsystem.vo;

public record AuthorRecord(Long id, String name, String description) {

}
